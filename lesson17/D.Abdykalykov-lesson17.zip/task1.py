lst = ['True', 5, 33, True, 1, -1, 0, False, '1', '33', 1]

for index, element in enumerate(lst):
    if element == True:
        print(index)