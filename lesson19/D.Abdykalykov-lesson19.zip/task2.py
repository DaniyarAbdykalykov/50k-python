my_lst = [e for e in range(-100, 101) if e % 5 == 0 or e % 3 == 0]
print(my_lst)