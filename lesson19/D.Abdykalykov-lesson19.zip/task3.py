mult_table = [(f"{i} * {j} = {i * j}") for i in range(1, 6) for j in range(1,11)]

print(mult_table)