for i in range(80, 19, -4):
    print(i)