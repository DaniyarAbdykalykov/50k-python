name = 'Абдыкалыков Данияр Джалилович;'
birthday = '3 февраля 1997 года;'
heigth = '182 см;'
hobby = 'футбол, сноубординг, туризм;'
favoriteMovie = '"Любовь. Смерть. Роботы"'

print('1', name, 
    '\n2.', birthday,
    '\n3.', heigth,
    '\n4.', hobby,
    '\n5.', favoriteMovie
)