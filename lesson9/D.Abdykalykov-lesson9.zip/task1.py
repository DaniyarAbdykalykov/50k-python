a = 5

b = a ** 2 == 10

print(b)        # True

 

a = 'ccc'

b = a + a * 2 < '2'

print(b)        # False

 

a = 'abc'

b = False

if a > 'ABC':

    b = True

print(b)        # True

 

a = True + True * False

b = a * 10

print(b)        # 10

 

a = 1

b = True

c = a == b

print(c)        # True