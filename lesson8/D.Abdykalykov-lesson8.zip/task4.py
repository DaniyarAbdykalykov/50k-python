num1 = int(input('Введите первое число: '))
num2 = int(input('Введите второе число: '))
num3 = int(input('Введите третье число: '))

if num1 > num2 > num3:
    print(num1 + num2)
elif num2 > num1 > num3:
    print(num2 + num1)
elif num1 > num3 > num2:
    print(num1 + num3)
elif num3 > num1 > num2:
    print (num3 + num1)
elif num2 > num3 > num1:
    print(num2 + num3)
elif num3 > num2 > num1:
    print(num3 + num2)