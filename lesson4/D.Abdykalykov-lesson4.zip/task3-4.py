str_1 = 'Я'

str_2 = 'хочу'

str_3 = 'стать'

str_4 = 'крутым'

str_5 = 'программистом!'

print(str_1 + ' ' + str_2 + ' ' + str_3 + ' ' + str_4 + ' ' + str_5)

print(f'{str_2} {str_3} {str_1} {str_4} {str_5}')