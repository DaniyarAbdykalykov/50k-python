a = 123               # int

c = -123              # int

b = -123.0            # float

d = 123.0             # float

e = 0.0               # float

f = 0                 # int

g = '123'             # str

h = "123"             # str

i = """123"""         # str