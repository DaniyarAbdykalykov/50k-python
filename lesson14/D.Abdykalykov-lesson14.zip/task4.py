string = input("Введите строку: ").lower()
print(len(string))

print(tuple(sorted(string)))