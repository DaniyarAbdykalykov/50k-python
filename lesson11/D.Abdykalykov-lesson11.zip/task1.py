word = 'программист'

a = word[1] + word[2] + word[9] + word[10]
b = word[-6] + word[-3] + word[-2] + word[-1]

print(a)
print(b)
print(f'{word[0]}{word[-3]}{word[1]}{word[5]}{word[-1]}')
print(f'{word[6]}{word[5]}{word[3]}{word[-3]}{word[-2]}{word[-1]}{word[1]}')
