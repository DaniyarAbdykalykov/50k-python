a = 100

b = 20

c = a / b       # 5.0 float

 

a = 100

b = 20

c = a // b       # 5 int

 

a = 25

b = 100

c = a / b       # 0.25 float

 

a = 25

b = 100

c = a // b       # 0 int

 

a = 10

b = 0

c = a / b       # на ноль делить нельзя

 

a = 10

b = 0

c = a // b       # на ноль делить нельзя

 

a = 0

b = 25

c = a / b       # 0.0 float

 

a = 0

b = 25

c = a // b       # 0 int

 

a = 100

b = 20

c = a % b       # 0 int

 

a = 20

b = 100

c = a % b       # 20 int