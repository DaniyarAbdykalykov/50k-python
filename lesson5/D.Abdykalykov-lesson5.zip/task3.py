a = 5

b = 2

c = a ** b       # 25 int

 

a = 121

b = 0.5

c = a ** b       # 11.0 float

 

a = 121

b = 0

c = a ** b       # 1 int

 

a = 3

b = 2

c = 3

d = a ** b ** c  # 729 int