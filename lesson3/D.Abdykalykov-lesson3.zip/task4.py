name = 'Чингиз'
middlename = 'Торекулович'
surname = 'Айтматов'
birthday = '12 декабря 1928 года'
date_of_death = '10 июня 2008 года'
degree = 'Народный писатель Киргизской ССР'
story1 = 'Первый учитель'
story2 = 'И дольше века длится день'
reward = 'Почётная премия культуры имени В. Гюго'
memory = 'В Будапеште открылся сквер имени Ч. Айтматова'

print('1.\t', name,
'\n2.\t', middlename,
'\n3.\t', surname,
'\n4.\t', birthday,
'\n5.\t', date_of_death,
'\n6.\t', degree,
'\n7.\t', story1,
'\n8.\t', story2,
'\n9.\t', reward,
'\n10.\t', memory
)